---
title: "An Intuitive Interpretation of Reynolds Number in Turbulence"
date: 2019-09-13T14:08:45-04:00
draft: false
toc: false
images:
tags:
  - educational
---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

## Where does the Reynold's Number come from?

If you've had hot coffee, you've probably noticed the really fast ripples that run across the surface of the liquid as you blow on it to cool it down. This system, your coffee, is quite similar the system of waves rolling across the ocean surface. So, why are the ripples on your coffee so much smoother than those on the Ocean? and why do they travel faster? why do oceanic waves produce foam, and coffee waves not so much?

The answer ultimately comes down to scales. While the physics of both systems are almost identical, the spatial and temporal scales are vastly different. This seemingly tiny difference drastically effects the dynamics available to each system. The Navier-Stokes equation, 
$$\rho\left(\frac{\partial u}{\partial t}+u\cdot\nabla u \right) = -\nabla p +\eta \nabla^2 u+f,$$
describes the evolution of a velocity field, $u=u(x,t)$. This function $u$ describes a relationship between meters, $x$, and seconds $t$, and the Navier-Stokes equation acts as a constraint on what that relationship can look like. If we were able to scale $x$ and $t$ and arrive back at another solution to Navier-Stokes, we would call this equation scale-invariant. Solutions are almost never scale-invariant, and that is why we see such a drastic difference between the dynamics in our coffee and in the ocean.  

We can show this rigorously by defining new [dimensionless variables](http://www.math.wisc.edu/~angenent/519.2014s/problems/non-dimensionalization.html), 
$$x = Xx^\*$$
$$u = Uu^\*$$
$$t = (X/U)t^\*$$
$$p = (1/\rho)p^\*$$
<!-- $$f = (X/\rho U^2)f^\*.$$ -->
In terms of these variables, the Navier-Stokes equation
$$\frac{\partial u^\*}{\partial t^\*}+u^\*\cdot\nabla u^\* = -\frac{1}{\rho}\nabla p^\*+ \frac{1}{Re}\nabla^2 u^\*+\frac{1}{Fr^2}f^\*,$$
has only two parameters, $Re = (\rho U X)/\eta$ and $Fr = U\sqrt{\frac{\rho}{X}}$. As the scale of the system changes, so do these parameters, and therefore the dynamics. $Re$ is called Reynold's number and $Fr$ is called the Froude number, both named after that physicists that first analyzed them. For oceanic systems, $Re$ is of order $10^4-10^8$, while in your morning cup of coffee its closer to $1-100$. We can now see explicitly that Reynolds number is a control parameter for how strongly dissipation ($\nabla^2 u^\*$) acts in our dynamics.

## How can we interpret the Reynolds Number in the turbulent regime?

This parameter has a very interesting interpretation in Kolmogorov's theory of turbulence. As $Re$ increases, our system becomes less dissipitive, so we should expect a larger range of structures in the flow. As we're about to show, this is precisely the case. 

In Kolmogorov's theory of turbulence, we consider a homogeneous and isotropic fluid whose dynamics is governed by eddys of various sizes. That is, although the fluid is riddled with turbulent vortices, any statitical averages of the flow are constant in space and time. In this system, two relevant scales are immidiately available, the diameter of a vortex $d$ and the speed of its outer edge $u$. From these scales we can determine a characteristic time scale, $t = \frac{\pi d}{u}\sim\frac{d}{u}$. This is how long it would take a tracer particle to make one full rotation around the outer edge of a vortex. 

Energy is fed into the system at some large scale $d\_{max}$, and cascades down from larger structures to smaller structures, as predicted by Kolmogorov scaling. The energy then leaves the system at some minimal scale $d\_{min}$ due to viscosity. 
<!-- We can label these structures sizes by wavenumber $k$, since large wavenumbers will corespond to very small wavelength structures in the system and small wavenumbers will correspond to large wavelength structures.  -->
Let $\epsilon$ be the energy being dissipated from the system every second. Since the system is in equilibrium, we expect the energy at each length scale $E(k)$ to remain roughly constant in time, meaning that 
$$| \text{energy leaving } E(k) | =| \text{energy entering } E(k) |  = \epsilon$$
for all $k$. The units of dissipation are 
$$[\epsilon] = \frac{\text{energy}}{\text{mass}\times\text{time}} = \frac{X^2}{T^3}.$$
By dimensional analysis, we can write this quantity in terms of our characteristic quantities 
$$\epsilon \propto \frac{u^3}{d}.$$
Typically vortices will dominate up to the characteristic length of the system, such that $d_{max}=X$ and $U = (\epsilon X)^{\frac{1}{3}}$. Vortices are bounded on smaller length scales by dissipation. Viscosity has dimensions 
$$[\nu] = \frac{X^2}{T}.$$
By dimensional analysis, we can write this quantity as 
$$\nu = \epsilon d^2/u^2 = d^{\frac{4}{3}}\epsilon^{\frac{1}{3}}.$$
Thus vortices will dissipear at length scale $d\_{min} = (\nu^3/\epsilon)^{\frac{1}{4}}$. 

With the groundwork now laid, and we are ready to show that 
$$\frac{d\_{max}}{d\_{min}} \sim \frac{X}{(X\nu^3/U^3)^{\frac{1}{4}}} = \left(\frac{UX}{\nu}\right)^{\frac{3}{4}} = Re^\frac{3}{4}$$
<!-- and the ratio  -->
$$\frac{u\_{max}}{u\_{min}} \sim \frac{(\epsilon d\_{max})^{\frac{1}{3}}}{(\epsilon d\_{min})^{\frac{1}{3}}} = \left(\frac{d\_{max}}{d\_{min}}\right)^{\frac{1}{3}} = Re^\frac{1}{4}.$$
<!-- Together this shows that **the Reynolds number, $Re$, is in fact**  -->
and
$$Re = Re^\frac{1}{4}Re^\frac{3}{4} = \frac{d\_{max}}{d\_{min}} \frac{u\_{max}}{u\_{min}} = \frac{\rho u\_{max} d\_{max}}{\rho u\_{min} d\_{min}} = \frac{L\_{max}}{L\_{min}}.$$
**In turbulence Reynolds, number is the ratio of the angular momenta between the largest eddies accessible to the system and the smallest.** 


Be sure to search by the tag [#educational](/tags/educational/) to see more posts like this!

A large portion of this work was inspired by [work done by Benoit Cushman-Roison](http://www.dartmouth.edu/~cushman/courses/engs250/Kolmogorov.pdf) at Dartmouth College. 

