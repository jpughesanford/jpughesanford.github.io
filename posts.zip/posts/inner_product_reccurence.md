---
title: "Computationally Efficient way of Determining Minimal Distance in Systems with Continuous Translational Symmetries"
date: 2019-09-20T13:49:07-04:00
draft: false
tags:
  - educational
---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

## Motivation 

Exact coherent structures (ECS) provide a simplified perspective on turbulence in which entire neighborhoods of points are pushed along a "current" created by an exact structure. Trajectories will continue along this characteristic flow of one ECS for a bit and get swept away by the "current" of another ECS. Formally, this  has allowed us to model statistical properties of the flow in terms of an expansion around the periodic orbits of the flow. While many interesting results have come from this perspective, such as [being able to write spatio-temporal averages in terms of an expansion about periodic orbits of the system](https://arxiv.org/abs/nlin/0001034), it remains a mystery how to efficiently build a library of all the ECS in a system. 

The prevailing method to search for periodic orbits in the literature is to do recurrence diagrams. given a state $u(x,t)$, a heatmap is generated 
<p align="Center"><img src="/innerproduct_1.png" style="width:500px; float:center; padding: 10px"></p>
where each pixel represents $$||u(x,t)-u(x,t-\tau)||^2.$$ This heatmap will have a minimum at $(t,\tau)$ when $u(x,t)$ lies in the vicinity of a periodic orbit of period $\tau$. 

In systems with continuous symmetries, which admit relative periodic solutions, this problem is much more complicated. A relative periodic orbit satisfies 
$$u(x,t)=u(x-l,t-\tau),$$
so depending on the value of $l$, we won't see a minimum at $(t,\tau)$ on our heatmap close to this orbit, becuase 
$$||u(x,t)-u(x,t-\tau)||^2 = ||u(x,t)-u(x-l,t)||^2 > 0.$$
To bypass this, researchers make a new heatmap where each pixel represents a minimization over $l$, 
$$\min_l||u(x,t)-u(x-l,t-\tau)||^2.$$

Depending on the needed accuracy, this minimization scheme takes an extremely long time, and prohibits us from running reccurence on long turbulent trajectories. This means we lose out on seeing a lot of potentially relevent orbits. 

## Solution

The solution is to speed of this minimization over $l$. To do this, lets consider two vectors, $u(x)$ and $v(x)$, where $v$ takes the place of a state that is possibly a shifted copy of $u$. Below we will show that there exists a function $0<F(l)<1$ such that 
$$\text{argmax } F(l) = \text{argmin } || v(x-l)-u(x)||^2.$$ 

**Proof** Suppose we shift $u$ by some value $l$ and write $v$ as a sum of its component along this shifted copy of $u$ and its component orthogonal to this shifted copy of $u$, 
$$v(x) = c_1(l)\ u(x-l)+c_2(l)\ u\_{\perp}(x-l).$$
We now want to choose $l$ such that we get as close to $c_1(l)=1, c_2(l)=0$ as possible. 

To proceed, we take the fourier transforms of both $u$ and $v$, 
$$u(x) = \int U(k)e^{i k x} dk$$
$$v(x) = \int V(k)e^{i k x} dk = \int \left[c_1(l)\ U(k)+c_2(l)\ U\_{\perp}(k)\right]e^{i k (x-l)} dk.$$
where by Plancherel's theorem, 
$$\int \overline{u(x)}u(x)dx = \int \overline{U(k)}U(k)dk = ||u||^2,$$
$$\int \overline{u(x)}u\_\perp(x)dx = \int \overline{U(k)}U\_\perp(k)dk = 0.$$

It follows that the the fourier transform of $\overline{U}V$ has the property, 
$$F(l) = \int \overline{U}Vdk = \int \overline{U(k)}\left[c_1(l)\ U(k)+c_2(l)\ U\_{\perp}(k)\right]e^{i k (-l)}e^{i k l}dk = c\_1(l) ||u||^2,$$
which allows us to probe the value of $c_1$ for all shifts $l$. An issue here is that we have no information on $u\_\perp$, it could be arbitrarily large... 

To overcome this, normalize $u$ and $v$ before finding $F$. Written in terms of the unnormalized vectors, it follows then that
<!-- $$ u(x) \mapsto \frac{u(x)}{||u||}$$
$$ v(x-l) \mapsto \frac{v(x-l)}{\sqrt{c_1(l)^2||u||^2+c_2(l)^2||u\_{\perp}||^2)}}.$$
It follows that  -->
$$F(l) = \frac{c_1(l)}{\sqrt{c_1(l)^2||u||^2+c_2(l)^2||u\_{\perp}||^2)}}.$$
intuitively, $F(l)$ now tells you the fraction of $v(x)$ that lies along $u(x-l)$, which diminishes as $u\_\perp$ increases. Moreover, $F(l)$ still has a maximum whenever $v$ is at its closest to $u$. 
<!-- In other word $F(l)=1$.  -->

This methods allows for a rapid minimization over the continuous translational symmetry. In my code, this method had a speedup of x60 over the usual brute force approach. Furthermore, this method extends to arbitrarily many symmetry directions, allowing for the possibility of minimizing over time as well, if one were to, say, need to find the minimal distance between two periodic orbits. 

In matlab, on a domain of length L with N gridpoints, 

```matlab
F = fft(conj(fft(u/norm(u))).*fft(v/norm(v))))
[~,index] = max(F)
phi = (L/N)*(index-1)
```

Thank you for reading. Be sure to search by the tag [#educational](/tags/educational/) to see more posts like this!
