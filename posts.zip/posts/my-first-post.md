---
title: "My First Post"
date: 2019-09-08T21:22:00-04:00
draft: false
toc: false
images: 

---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

I finally got GitHub working as a host for the site! Starting this Friday, I'm going to start posting weekly research updates ([#researchupdate](/tags/researchupdate/)), to both track my progress and work on my techinical writing skills. Certain posts might not be made public right away, but as soon as the research that it concerns is published, y'all will get to read it. In addition to that, I plan on posting fun and interesting concepts or derivations I learn along the way under the tag ([#educational](/tags/educational/)). 

I even got $$equations$$ working. 