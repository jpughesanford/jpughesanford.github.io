---
title: "Research Update November 29"
date: 2019-11-29
draft: true
tags:
  - researchupdate
---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

This past weekend I attended my very first conference! I presented my work in the Non-Linear Dynamics and Coherent Structures session at the APS, Division of Fluid Dynamics conference in Seattle. A video of my talk and a link to my slides can be found [here](/showcase). 

To summarize the work that I presented: many dynamical systems exhibit irregular behavior, and when they do, these "extreme events" are often quite catastrophic. These kinds of events include heart attacks, seizures, extreme weather patterns, earthquakes, and more. We need to better understand how to predict and control these kinds of events, and an essential step in doing that is understanding how they work. 

I study these kinds of events in two-dimensional Kolmogorov flow. In my talk, I present evidence that only a collection of trajectories mediate these events, and I find a single member of this collection. I then show that the flow closely follows the dynamics of this member every time extreme behavior occurs. This work gives us a generalized, novel framework in which to understand extreme behavior in dynamical systems, and could help us compare extreme event production in dissimilar systems. 

### Correction

In my talk, I gave a physical explanation of extreme behavior in the Kolmogorov flow. I argued that extreme behavior is due to an alignment of the velocity field with the external forcing profile. I argued that, due to this alignment, a lot of energy is injected into the system, which is then dissipated, causing extreme behavior. After a great talk with [Mohammad Farazmand](https://scholar.google.com/citations?user=0P48E8gAAAAJ&hl=en&oi=ao), I am convinced this is not the correct way to think about it. 

In [figure S1](https://advances.sciencemag.org/content/advances/suppl/2017/09/18/3.9.e1701533.DC1/1701533_SM.pdf) of the supplementary material of his Science Advances paper, Farazmand shows that the flow field is almost always perfectly aligned with the forcing profile. Therefore, this couldn't be responsible for extreme behavior. Instead, it seems cross-roll instabilities in the system mediate extreme behavior. The most dynamically relevant Fourier mode in the system is $(1,0)$, because this mode minimizes both frustrations with the forcing as well as the shear held in the fluid. This mode has a cross-roll instability and is unstable to the forcing wavenumber $(0,k_f)$.  At the onset of this instability, the forcing profile exacerbates the growth rate of the $(0,k_f)$ Fourier mode. This creates shear stresses in the flow and thus leads to extreme behavior. 

Be sure to search by the tag [#researchupdate](/tags/researchupdate/) to see more posts like this!