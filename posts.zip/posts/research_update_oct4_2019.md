---
title: "Research Update October 4"
date: 2019-10-04T12:00:32-04:00
draft: false
tags:
  - researchupdate
---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

This week was spent mostly working and fine tuning fellowship applications. That said, this week also required some careful thought into the phase space structure underlying extreme events. Previously, I had been converging a relative periodic orbit that seemed to lie in both the high dissipation and low dissipation regimes of the kolmogorov flow at $Re=40$. Both adjoint looping and direct newton iterations were used to try and converge this orbit, but both converged relatively slowly when compared to other RPOs converged at this Reynolds number and were stopped. That said, the relative residual attained from Newton was small enough to warrant more time investigating this potential RPO. 

<p align="center"><img src="/rusep27_1.pdf" style="width:500px; float:center; padding: 10px"></p>

This potential RPO was found when searching for heteroclinic between high-dissipation and low-dissipation solutions. The possibility exists that this is not actually an RPO, but instead a heteroclinic/homoclinic connection that makes a close pass back upon itself (as in the diagram above). This would explain the local minimum found, although it would not explain the poor convergence of the solvers about this potential solution. 

To explore this possibility further, we ran a calculation to see how close the turbulent trajectory was to other known solutions before and after extreme events (including the extreme event that lead us to this potential RPO in the first place). We found that the turbulent trajectory never made a close pass to any known high dissipation solutions. However, is did make close passes to a known travelling wave solution and a known periodic orbit before and after each highly dissipitive event. If a heteroclinic were to exist instead of an RPO (such as in the diagram above), its likely that the travelling wave RE100 and or the periodic orbit PO01 take the place of the endpoints. 

To more rigorously analyze which of these states are likely to support connections, we analyzed their spectra, below are the tabulated results
<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg .tg-0lax{text-align:left;vertical-align:top}
</style>
<table class="tg" align="center">
  <tr>
    <th class="tg-0lax"></th>
    <th class="tg-0lax">Type</th>
    <th class="tg-0lax">$\text{dim }W^u$</th>
    <th class="tg-0lax">$\text{argmax Re}(\lambda)$</th>
  </tr>
  <tr>
    <td class="tg-0lax">RE100</td>
    <td class="tg-0lax">Traveling Wave</td>
    <td align="center">$5$</td>
    <td align="center">$0.0681\pm i0.1203$</td>
  </tr>
  <tr>
    <td class="tg-0lax">PO01</td>
    <td class="tg-0lax">Periodic Orbit</td>
    <td align="center">$7$</td>
    <td align="center">$0.1910\pm i0.2703$</td>
  </tr>
  <tr>
    <td class="tg-0lax">UT01</td>
    <td class="tg-0lax">Unconverged Trajectory</td>
    <td align="center">$6$</td>
    <td align="center">$0.1818$</td>
  </tr>
  <tr>
    <td class="tg-0lax">UT02</td>
    <td class="tg-0lax">Unconverged Trajectory</td>
    <td align="center">$8$</td>
    <td align="center">$0.2885$</td>
  </tr>
</table>

Analyzing the dimension and codimesion of the unstable manifold gives us a better ideas of which solutions be the initial and final points on a heteroclinic connection. 

<!-- Interestingly enough, the unconverged solutions appear to have marginal modes in their spectra. Farazmand and Sapsis found that [intermittent events only occur in this system above Re=35](https://doi.org/10.1126/sciadv.1701533). If exact coherent structures are indeed the backbone of this process, it's likely that a bifurcation occurs at $Re=35$ to facilitate this process. It follows that the culpable ECS would have a nearly marginal mode so close to a bifurcation. This further supports the hypothesis that we are close to converging the culpable ECS. To better converge on this solution, I plan on increasing the Reynolds number and converging on the solution in a regime where the stability is less marginal, and then using parameter continuation to trace it back down to the current parameter regime.  -->


Be sure to search by the tag [#researchupdate](/tags/researchupdate/) to see more posts like this!
