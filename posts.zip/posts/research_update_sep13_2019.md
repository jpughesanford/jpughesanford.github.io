---
title: "Research Update September 13"
date: 2019-09-14T21:16:25-04:00
draft: false
toc: false
images:
  - static/rusep13_1.png
tags:
  - researchupdate
---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

The majority of this weeks work was understanding the mechanism behind extreme events in the 2D Kolmogorov flow. These extreme are charactierized by short lived bursts ($\sim .3\ Jkg^{-1}s^{-1}$) in dissipation far above its expected value ($\sim .1\ Jkg^{-1}s^{-1}$). 

The laminar state is possibly one of the most highly dissipitive states on the attractor, scaling as $\frac{1}{32}Re$ in my particular setup. Above $Re\sim10-20$, this state becomes unstable to states with lower dissipation. Understanding the state space structures that allow for excursions back into the high-dissipation/close-to-laminar regime are crucial. 

The search for coherent structures to date begins with reccurence diagrams and these needs to be run on long, long turbulent trajectories. In order to expand the search for relative periodic orbits, these need to calculate 
$$\min_{l\in[0,2\pi)} ||u(x,t)-T_l\ u(x,t-\tau)||^2$$
where $T$ is the translation operator along some continuous symmetry. This can obviously become quite computationally expensive, and to combat this bottle, Predrag Cvitanović came up with a method to [quotient out the continous symmetry](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.114.084102). The issue with this method is that is requires knowledge of a "relevant", non-zero mode throughout the trajectory. It is quite difficult to choose such a mode in practice, as the relevant modes change often over the course of a turbulent trajectory, leading to artifacts in the reccurence plots that detract from finding structures. 

In search of finding this relevant mode, I binned the state into high-dissipation and low-dissipation bins and plotted their average wavenumber (upper row) and velocity (lower row) fields. 
<p align="Center"><img src="/rusep13_1.png" style="width:700px; float:center; padding: 10px"></p>
From this I can say that the system visits the high dissipation regime about ~3% of the time, and that the $k=(2, 0)$ mode is much more important in the high-dissipation regime, while the $k=(1,0)$ mode is more important in the low dissipation regime. That said, the mode $k=(1,4)$ seems to be available to both. This could be a potentially perfect mode for the symmetry reduction scheme. If this not work, we may need to look into multi-mode methods, or some other more dynamic method of symmetry reduction along the trajectory. 

Despite these issues with recurrence, three new equilibria were found in the high-dissipation regime, along with a pre-periodic orbit (shown below). Due to the high state space speed that we observe in the dissipitive regime, I doubt that these equilibria will be relevant to finding the transition mechanism causing extreme events. Orbits, and the connections between them, are much more likely candidates. 

<div>
<p align="Left"><img src="/rusep13_2.png" style="width:250px; float: left; padding: 10px"></p>
<p align="Center"><img src="/rusep13_3.png" style="width:250px; float: left; padding: 10px"></p>
<p align="Right"><img src="/rusep13_4.png" style="width:250px; float: left; padding: 10px"></p>
</div>
<p align="Center"><img src="/rusep13_5.gif" style="width:700px; float: center; padding: 50px"></p>

Be sure to search by the tag [#researchupdate](/tags/researchupdate/) to see more posts like this!

