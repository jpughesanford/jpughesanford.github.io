---
title: "Research Update September 20"
date: 2019-09-20T13:17:20-04:00
draft: false
tags:
  - researchupdate
---

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
  jax: ["input/TeX", "output/HTML-CSS"],
  tex2jax: {
  	inlineMath: [['$','$'], ['\\(','\\)']], 
  	displayMath: [['$$','$$']],
    skipTags: ["script","noscript","style","textarea","pre"],
    processEnvironments: true
	}
});
</script>
<script src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>

Using the quotient method as referenced in my previous update was unsuccesful. The dynamically relevant modes are rather different between the high-dissipation and low-dissipation lobes of the attractor. Modes that are common to both lobes tend to have pass through zero throughout the transitions between lobes, causing sparatic behavior in the quotienting method. There are well developed methods to bypass this issue in the literature, such as [forming an atlas of charts on the full space, each chart describing a specific way to reduce the symmetry of its own section of the full space](http://www.cns.gatech.edu/~predrag/papers/atlas12.pdf). These methods are beautifully rigorous, but often hard to implement numerically in a way that doesn't require human supervision. 

To overcome this hurdle, I developed a fast numerical method for [determining the minimum distance between states in systems with arbitrarily many continuous symmetries](https://jpughesanford.github.io/posts/2019/09/numerical-scheme-for-recurrence-in-systems-with-continuous-translational-symmetries/). This method performs as quickly as the true symmetry reduction method proposed by Predrag. In addition, this method is state-independent, meaning that it will work well regardless of what modes are relevant, or where we are in phase space. 

Using this method, I have generated a plethora of states that corresponds to close passes to exact coherent structures in my system. One close pass, in particular, seems to pass close to a relative periodic orbit that has sections in both the high dissipation and low dissipation regimes. Therefore, any trajectory that saddles this orbit will be a trajectory that exhibits an extreme event. I am coverging this solution using direct-adjoint iterations as I type this.


Be sure to search by the tag [#researchupdate](/tags/researchupdate/) to see more posts like this!
